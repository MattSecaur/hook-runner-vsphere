#!/usr/bin/env bash

python.py "../../../../contrib/inventory/vmware_inventory.py" "$@"
